package review;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;


import java.util.*;
import review.Review;

public class ReviewDAO {
	private Connection conn;
	private PreparedStatement pstmt;
	private ResultSet rs;
		
	//		---------- DB���� ----------  //
	public ReviewDAO() {
		try {
			String dbURL = "jdbc:mysql://localhost:3306/mnr";//mysql ��ġ
			String dbID = "root";//mysql ID
			String dbPassword = "root";//mysql PASSWORD
			Class.forName("com.mysql.cj.jdbc.Driver");//���� ����̹�
			conn=DriverManager.getConnection(dbURL, dbID, dbPassword);//DB�������� �� ����
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public ArrayList<Review> getDBList(String name) {
		ArrayList<Review> datas = new ArrayList<Review>();
		
		String sql = "select * from review where mtype='"+name+"' order by num asc";
		try {
			PreparedStatement pstmt=conn.prepareStatement(sql);
			rs=pstmt.executeQuery();
			while(rs.next()) {
				Review review = new Review();
				review.setNum(rs.getInt(1));
				review.setMtype(rs.getString(2));
				review.setTitle(rs.getString(3));
				review.setContent(rs.getString(4));
				review.setWriteDate(rs.getString(5));
				datas.add(review);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return datas;
	}
	public boolean insertDB(Review review, String name) {
		String sql = "insert into review(mtype, title, content, writeDate) values (?,?,?,?)";
		Date today = new Date();
		SimpleDateFormat date = new SimpleDateFormat("yyyy/MM/dd");
		try {
			PreparedStatement pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, name);
			pstmt.setString(2, review.getTitle());
			pstmt.setString(3, review.getContent());
			pstmt.setString(4, date.format(today));
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public Review getReview(int num) {
		String SQL = "SELECT * FROM review WHERE num = ?";
		try {
			PreparedStatement pstmt=conn.prepareStatement(SQL);
			pstmt.setInt(1,num);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				Review review = new Review();
				review.setNum(rs.getInt(1));
				review.setMtype(rs.getString(2));
				review.setTitle(rs.getString(3));
				review.setContent(rs.getString(4));
				review.setWriteDate(rs.getString(5));
				return review;
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return null;
		
	}
}
